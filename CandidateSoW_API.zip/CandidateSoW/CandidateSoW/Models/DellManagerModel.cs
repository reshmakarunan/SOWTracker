﻿namespace CandidateSoW.Models
{
    public class DellManagerModel
    {
        public int DellManagerId { get; set; }
        public string DellManagerName { get; set; } = "";
        public string Type { get; set; } = "";
    }
}
